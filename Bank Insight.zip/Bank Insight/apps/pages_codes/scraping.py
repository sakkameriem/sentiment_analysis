from flask import Blueprint, render_template, request
import pandas as pd
from datetime import datetime
from pymongo import MongoClient, errors
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import facebook_scraper as fs
import re
import time
import plotly.express as px
import plotly.io as pio
import random
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import numpy as np
from sklearn.metrics import (
    precision_score, 
    recall_score, 
    f1_score, 
    roc_auc_score, 
    roc_curve, 
    confusion_matrix, 
    log_loss
)


MAX_COMMENTS = True

comments_scraping_bp = Blueprint('comments_scraping_bp', __name__, template_folder='templates')


def clean_post_id(post_url):
    if "?" in post_url:
        post_url = post_url.split("?")[0]
    return post_url.split('/')[-1]


def login_to_facebook(driver, email, password):
    driver.get("https://www.facebook.com")
    email_field = driver.find_element(By.ID, "email")
    email_field.send_keys(email)
    password_field = driver.find_element(By.ID, "pass")
    password_field.send_keys(password)
    login_button = driver.find_element(By.CSS_SELECTOR, 'button[name="login"]')
    login_button.click()
    time.sleep(5)


def scrape_posts(driver, page_url, post_limit):
    login_to_facebook(driver, "marcginny2@gmail.com", "pr0jetwevi002024")
    driver.get(page_url)
    post_ids = []

    while len(post_ids) < post_limit:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)

        try:
            post_links = driver.find_elements(By.CSS_SELECTOR, "[href*=\"posts/\"]")
            for post_link in post_links:
                post_url = post_link.get_attribute("href")
                post_id = clean_post_id(post_url)
                if post_id not in post_ids:
                    post_ids.append(post_id)
                    if len(post_ids) >= post_limit:
                        break
        except Exception as e:
            print(f"Error finding post links: {e}")
            break

    return post_ids


def save_comments_to_mongodb(comments, db, collection_name):
    try:
        comments_collection = db[collection_name]
        comments_collection.delete_many({})
        comments_collection.insert_many(comments)
        print(f"Successfully saved {len(comments)} comments to MongoDB collection '{collection_name}'")
    except Exception as e:
        print(f"Error saving comments to MongoDB: {e}")


def clean_text(text):
    cleaned_text = re.sub(r'\s+', ' ', text).strip().lower()
    return cleaned_text


def extract_bank_name(page_url):
    
    bank_name_part = page_url.split('/')[3]
    bank_name_part = re.sub(r'[./_/-]', ' ', bank_name_part) 
    bank_name_part = re.sub(r'([a-z])([A-Z])', r'\1 \2', bank_name_part)
    bank_name_part = re.sub(r'\b(de|du|des|d\'|d’|banque|Bank|bank)\b', r' \1', bank_name_part, flags=re.IGNORECASE)
    bank_name_part = re.sub(r'\b(page|officielle)\b', '', bank_name_part, flags=re.IGNORECASE)
    bank_name_part = re.sub(r'\s+', ' ', bank_name_part).strip()

    words = bank_name_part.split()
    if words:
        capitalized_words = [words[0].capitalize()] + [word.lower() if word.lower() in ["de", "du", "des", "d'"] else word.capitalize() for word in words[1:]]
        bank_name = ' '.join(capitalized_words)
    else:
        bank_name = ''
    
    return bank_name


def generate_plotly_chart(melted_df):
    melted_df['Post Time'] = pd.to_datetime(melted_df['Post Time'])
    melted_df['Year-Month-Day'] = melted_df['Post Time'].dt.strftime('%Y-%m-%d')

    all_days = pd.date_range(start=melted_df['Post Time'].min(), end=melted_df['Post Time'].max(), freq='D').strftime('%Y-%m-%d')
    all_combinations = pd.MultiIndex.from_product([all_days, melted_df['Type'].unique()], names=['Year-Month-Day', 'Type'])
    sentiment_counts = melted_df.groupby(['Year-Month-Day', 'Type']).size().reindex(all_combinations, fill_value=0).reset_index(name='Counts')
    
    material_colors = {
        'Posts': '#e91e63',  
        'Comments': '#9c27b0'  
    }

    fig = px.bar(sentiment_counts, x='Year-Month-Day', y='Counts', color='Type',
                 labels={'Year-Month-Day': 'Date', 'Counts': 'Count', 'Type': 'Type'},
                 color_discrete_map=material_colors, barmode='stack')
    
    fig.update_layout(
        xaxis_title='Date',
        yaxis_title='Count',
        xaxis=dict(
            title_font=dict(size=14),
            tickfont=dict(size=12),
            type='category',
            categoryorder='category ascending'
        ),
        yaxis=dict(
            title_font=dict(size=14),
            tickfont=dict(size=12),
        ),
        template='plotly_white',
        plot_bgcolor='white',
        paper_bgcolor='white',
        font=dict(color='black'),
        legend_title_text='Type',
        legend=dict(
            orientation='h',  
            yanchor='bottom',  
            y=1.15,  
            xanchor='center',  
            x=0.5,
        ),
        title_font_size=26,
        legend_font_size=12
    )
    
    fig.update_traces(
        hovertemplate='Date: %{x}<br>Type: %{color}<br>Count: %{y}<br>',
        texttemplate='%{y}',
        textposition='top right',
        textfont_size=14
    )

    chart_html = fig.to_html(full_html=False)
    return chart_html
    
keywords = {
    "Celebration/Event": ["ouvertes","أحر", "التهاني", "Siège social", "salon international", "stand", "غابة", "حلقة", "talkshow", "remercie",
                            "بكالوريا", "أمي", "Coming", "Ifm", "Radio Ifm", "هدية", "مسابقة", "مولد", "شهداء", "مدرسية",
                            "رمضان", "كريم", "القرعة", "🇹🇳", "مرأة", "القدوة", "وفاة", "تحيا", "مفاجأة", "يتمنالكم",
                            "شريف", "كادوات", "بأحر التعازي", "مربوحة", "match", "الفرحة", "مساهمتكم", "بسبب", "مستقلة",
                            "خير", "عيد", "مباركة", "شكرا", "كل عام", "بخير", "مبروك", "حظ", "إن شاء الله بالنجاح", "jeu",
                            "concours", "شارك", "شاركوا", "ربح", "طلع", "طلّع"],

    "New branch opening": ["فرع", "افتتاح", "فروع"],
    "Auto loan": ["Hyundai", "opel", "سيّارة", "شاحنات", "سيارات", "voiture", "auto", "véhicule", "كرهبة", "سيارة",
                    "كميون", "مستحق", "Berlingo", "Citroën", "mahindra", "ford"],
    "Personal loan": ["نفقات", "Istithmar", "Robot", "médical", "matériel", "soldes", "Black Friday", "صيف", "سافر",
                        "رحلات", "gamer", "ordinateur", "تليفون", "watch", "Galaxy", "أثاث", "meuble", "hôtel", "piscine",
                        "تفرهيدة", "روسيا", "المعدات", "مشتريات", "معدات", "العرس", "مصروف", "shopping", "صحيّة", "السفر",
                        "voyage", "Samsung", "lave vaisselle", "machine", "Télé", "smartphone", "refrigerateur",
                        "cuisiniere", "PC", "TV", "عمرة", "رحلة", "projet", "مشروع", "مشروعك", ],
    "Home loan": ["Tamouil Menzel", "البني", "طبية", "سفر", "حج", "الدّار", "bien", "immobilier", "maison",
                    "appartement", "عقار", "بيت", "شقة", "سكني", "منزل", "تحسينات", "بناءات", "تحسين", "بناء", "مكتب",
                    "محل", "تجاري", "عقارات", "مؤسسات", "دار", "دارك", "أرض"],
    "Student loan": ["مستقبلك", "دراسة", "قراية", "دراسات", "الجامعات", "جامعة خاصّة", "faculté", "étudie", "études",
                        "étude", "الباك", "الجامعة", "يقرى", "تقرى"],
    "Money transfer/Online banking": ["Hisseb Racid", "الخارج", "الإلكترونية", "الأنترنت ", "الأنترنات", "à distance",
                                        "الانترنات", "الالكتروني", "موزع آلي", "مو", "بطاقات", "بطاقة", "carte",
                                        "MasterCard", "البطاقة التكنولوجية", "paiement sans contact", "تواصل",
                                        "l’étranger", "العملة", "tawassol", "application", "technologique",
                                        "carte technologique", "ما تتنقل", "عن بعد", "TPE", "en ligne",
                                        "مواطينينا بالخارج", "devise", "تبدلو", "تحويل الأموال", "western union", "ria",
                                        "moneygram", "حوالة", "Visa"],
    "Saving": ["خزنة", "Tawfir", "الادّخار", "توفير"]}

def classify_post(caption):
    keyword_count = {
        "Celebration/Event": 0,
        "New branch opening": 0,
        "Auto loan": 0,
        "Personal loan": 0,
        "Home loan": 0,
        "Student loan": 0,
        "Money transfer/Online banking": 0,
        "Saving": 0,
        "Other": 0
    }

    for key, words in keywords.items():
        for word in words:
            if bool(re.search(word, caption, re.IGNORECASE)):
                keyword_count[key] += 1
 
    max_count = 0
    category = None
    for key, count in keyword_count.items():
        if count > max_count:
            max_count = count
            category = key
    if max_count == 0:
        category = "Other"

    return category

def generate_pie_chart(data_df):
    product_counts = data_df['Classification'].value_counts()

   
    material_dashboard_colors = [
    '#9c27b0',  # Purple
    '#2196f3',  # Blue
    '#3FD145',  # Green
    '#ff9800',  # Orange
    '#00E3FF',  # Cyan
    '#ffc107',  # Amber
    '#e91e63',  # Pink
    '#03a9f4',  # Light Blue
    '#FFF007',  # Deep Orange
    '#f44336',  # Red
    ]

    selected_colors = random.sample(material_dashboard_colors, len(product_counts))

    fig = px.pie(
        product_counts,
        names=product_counts.index,
        values=product_counts.values,
        labels={'Number of comments': 'Number of comments', 'Classification': 'Banking Product'},
        color_discrete_sequence=selected_colors,
        hole=0.3, 
    )

    
    fig.update_traces(
        textinfo='percent',  
        textfont_size=12,  
        textfont_color='black', 
        marker=dict(line=dict(color='white', width=2))  
    )

    fig.update_layout(
        template='plotly_white', 
        plot_bgcolor='white',
        paper_bgcolor='white',
        font=dict(color='black'),  
        legend_title_text='Banking Product', 
        legend=dict(
            orientation='h',  
            yanchor='bottom', 
            y=1.02, 
            xanchor='center',  
            x=0.5, 
        ),
        legend_font_size=12
    )
    
    chart_html = fig.to_html(full_html=False)
    return chart_html

tokenizer = AutoTokenizer.from_pretrained("AhmedBou/TuniBert")
model = AutoModelForSequenceClassification.from_pretrained("AhmedBou/TuniBert")

neutral_words = ["gedech", "kifech", "kifesh", "n7eb na3ref", "nheb", "استفسار",
                 "na3rif", "n7b", "n7ib", "nheb na3ref", "prix", "details",
                 "détails", "ma3loumet", "معلومات", "information", "kifch", "kifach",
                 "kifh", "ثمن", "تفاصيل", "قداش", "الثمن", "كيفاش", "نحب نعرف", "comment faire pour",
                 "ما هي الاجراءات", "بقداش", "b9adech", "b9adeh", "9adeh", "9adech", "kadesh", "kadech",
                 "bkadesh", "bkadech", "win", "wa9teh", "wakteh", "wa9tech", "فين",
                 "eb9adach", "الاجراءات", "procedures", "procédures", "كفاش", "رقم", "interesse", "interessé", "قداه",
                 "قدش", "https", "هل يمكن", "شراء", "تعطيو", "كيف يمكن", "تتمثل", "نحب نشرى", "نحب نشري", "بقديش",
                 "kifche", "السعر", "enajem", "najjem", "enajim", "inajim", "تحلو", "t7elou", "thelou", "thelo", "ميساج",
                 "انجم ناخو", "أين", "وين", "svp", "stp", "najem", "nejem", "المطلوبة", "7achti", "كيفية", "ينجم", "مطلوب", "ما العمل", "نحب ناخذ", "نجم ناخذ", "نجم", "bilah",
                "هل الشروط", "نحب نعمل", "wiyn", "ouin", "هل ممكن", "نحب", "اعمل طلة", "تشريو الكريدي", "nhb","n7eb", "كفاه", "وقتاش", "تفسير",
                "gadech", "9adah", "tafasil"]

def is_neutral(text):
    return any(word in str(text).lower() for word in neutral_words)

client = MongoClient("mongodb://localhost:27017/")
db = client['Mydata']
source_collection = db['cleaned_comments']
target_collection = db['labeled_comments']

def perform_sentiment_analysis():
    target_collection.delete_many({})
    print("Previous data deleted from target collection")

    documents = list(source_collection.find())
    batch_size = 1000
    batch_results = []

    for doc in documents:
        text = doc['Comment']
        tokens = tokenizer.encode_plus(text, return_tensors="pt", max_length=512, truncation=True)
        outputs = model(**tokens)
        logits = outputs.logits.detach().numpy()
        predictions = np.argmax(logits, axis=1)
        sentiment_label = "neutral" if predictions[0] == 0 else "positive" if predictions[0] == 1 else "negative"

        doc['label'] = sentiment_label
        batch_results.append(doc)

        if len(batch_results) >= batch_size:
            try:
                target_collection.insert_many(batch_results, ordered=False)
            except errors.BulkWriteError as e:
                print(f"Erreur lors de l'insertion en masse : {e.details}")
            batch_results = []

    if batch_results:
        try:
            target_collection.insert_many(batch_results, ordered=False)
        except errors.BulkWriteError as e:
            print(f"Erreur lors de l'insertion en masse : {e.details}")

    print("Sentiment analysis completed and results saved to MongoDB.")


def update_labels():
    documents = target_collection.find(no_cursor_timeout=True)
    try:
        for doc in documents:
            text = doc['Comment']
            if is_neutral(text):
                target_collection.update_one({'_id': doc['_id']}, {'$set': {'label': 'neutral'}}, upsert=True)
                print(f"Updated document {doc['_id']} to neutral")
    finally:
        documents.close()
    print("Label update completed")


def generate_sentiment_pie_chart(data_df):
    color_map = {
        'positive': '#4CAF50',  
        'negative': '#F44335',
        'neutral': '#FFC107',  
    }
    data_df['label'] = data_df['label'].astype('category')
    data_df['label'] = data_df['label'].cat.set_categories(['positive', 'negative', 'neutral'], ordered=True)
    

    sentiment_counts = data_df['label'].value_counts().sort_index()

    fig = px.pie(
        sentiment_counts,
        names=sentiment_counts.index,
        values=sentiment_counts.values,
        color=sentiment_counts.index,
        color_discrete_map=color_map
    )

    fig.update_traces(
        textinfo='label+value', 
        textfont_size=12,
        textfont_color='black',
        marker=dict(line=dict(color='white', width=2))
    )

    fig.update_layout(
        template='plotly_white',
        plot_bgcolor='white',
        paper_bgcolor='white',
        font=dict(color='black'),
        legend_title_text='Sentiment',
        legend=dict(
            orientation='h',
            yanchor='bottom',
            y=1.02,
            xanchor='center',
            x=0.5,
        ),
        legend_font_size=12
    )

    sentiment_analysis_pie_chart_html = fig.to_html(full_html=False)
    return sentiment_analysis_pie_chart_html


def generate_banking_products_bar_chart(data_df):
    if 'Classification' not in data_df.columns or 'label' not in data_df.columns:
        raise ValueError("Dataframe must contain the needed columns")
    
    product_sentiment_counts = data_df.groupby(['Classification', 'label']).size().reset_index(name='count')

    product_sentiment_pivot = product_sentiment_counts.pivot(index='Classification', columns='label', values='count').fillna(0)
    product_sentiment_pivot = product_sentiment_pivot.reset_index()

    fig = px.bar(
        product_sentiment_pivot,
        x='Classification',
        y=['positive', 'negative', 'neutral'],
        labels={'value': 'Count', 'Classification': 'Banking Product'},
        barmode='stack',
        color_discrete_map={
            'positive': '#4CAF50',  # Green
            'negative': '#F44335',  # Red
            'neutral': '#FFC107',   # Yellow
        }
    )

    fig.update_layout(
        template='plotly_white',
        plot_bgcolor='white',
        paper_bgcolor='white',
        font=dict(color='black'),
        legend_title_text='Sentiment',
        legend=dict(
            orientation='h',
            yanchor='bottom',
            y=1.02,
            xanchor='center',
            x=0.5,
        ),
        legend_font_size=12
    )

    banking_products_bar_chart_html = fig.to_html(full_html=False)
    return banking_products_bar_chart_html

def generate_sentiment_timeline_chart(data_df):
    if data_df.empty:
        return "<p>No data to generate the sentiment timeline chart.</p>"
    
    data_df['Post Time'] = pd.to_datetime(data_df['Post Time'])
    data_df['Year-Month-Day'] = data_df['Post Time'].dt.strftime('%Y-%m-%d')
    
    all_days = pd.date_range(start=data_df['Post Time'].min(), end=data_df['Post Time'].max(), freq='D').strftime('%Y-%m-%d')
    all_combinations = pd.MultiIndex.from_product([all_days, data_df['label'].unique()], names=['Year-Month-Day', 'label'])
    sentiment_counts = data_df.groupby(['Year-Month-Day', 'label']).size().reindex(all_combinations, fill_value=0).reset_index(name='Counts')
    

    color_map = {
        'positive': '#4CAF50',  # Green
        'negative': '#F44335',  # Red
        'neutral': '#FFC107',   # Orange
    }
    

    fig = px.line(sentiment_counts, x='Year-Month-Day', y='Counts', color='label',
                  color_discrete_map=color_map, markers=True)
    
    
    fig.update_layout(
        paper_bgcolor='white', 
        plot_bgcolor='white',  
        title_font=dict(size=18, color='black'),  
        xaxis_title='Date',
        yaxis_title='Counts',  
        xaxis=dict(tickmode='linear'), 
        legend=dict(
            title='Sentiment',
            orientation="h", 
            yanchor="bottom",    
            y=1.1,               
            xanchor="center",   
            x=0.5                  
        )
    )
    
    timeline_chart_html = pio.to_html(fig, full_html=False)
    return timeline_chart_html

@comments_scraping_bp.route('/scrapecom', methods=['POST'])
def scrape():
    page_url = request.form['url']
    num_posts = int(request.form['numPosts'])
    bank_name = extract_bank_name(page_url)
    
    chrome_options = Options()
    chrome_options.add_argument("--headless") 
    chrome_driver_path = "C:\\Windows\\System32\\chromedriver.exe"
    service = Service(chrome_driver_path)
    service.start()
    driver = webdriver.Chrome(service=service, options=chrome_options)
    
    scraping_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cleaned_comments_count = 0
    
    try:
        post_ids = scrape_posts(driver, page_url, num_posts)
        client = MongoClient("mongodb://localhost:27017/")
        db = client['Mydata']
        raw_comments_collection_name = "raw_comments"
        cleaned_comments_collection_name = "cleaned_comments"
        
        successful_posts = 0
        comments_list = []
        cookies = { 
            'c_user': '61556291402060', 'datr': 'k_OoZmYSvKgLiXI3Xx1qnTLe', 'dpr': '1.25', 
            'fr': '0kPLaMwxpE8qn1Er1.AWXZ-dByENw-jS3fRmRswf471zY.BmqPOT..AAA.0.0.BmqPPU.AWXhrtqGarM', 
            'presence': 'C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1722348523144%2C%22v%22%3A1%7D', 
            'sb': 'k_OoZnFcefzJ7vsV5NWtPYlC', 'wd': '543x695', 
            'xs': '27%3Au0Pp3G8aNys66A%3A2%3A1722348496%3A-1%3A16024' 
        }
        email = "marcginny2@gmail.com"
        password = "pr0jetwevi002024"
    
        
        for post_id in post_ids:
            print(f"Scraping comments for post {post_id}...")
            gen = fs.get_posts(
                post_urls=[post_id], 
                options={"comments": MAX_COMMENTS, "progress": True}, 
                cookies=cookies
            )
            
            try:
                post = next(gen)
            except StopIteration:
                print(f"No posts found for post ID: {post_id}")
                continue
                
            if 'comments_full' not in post:
                print(f"No comments found for post with ID: {post_id}")
                continue
            
            post_caption = post.get('post_text', '')
            post_time = post.get('time', '')
            comments = post['comments_full']
            post_classification = classify_post(post_caption)

            for comment in comments:
                commenter_name = comment['commenter_name']
                comment_text = clean_text(comment['comment_text'])
                comments_list.append({
                    'Bank': bank_name, 
                    'Post ID': post_id, 
                    'Post Caption': post_caption, 
                    'Post Time': post_time, 
                    'Commenter': commenter_name, 
                    'Comment': comment_text, 
                    'Scraping Time': scraping_timestamp,
                    'Classification': post_classification
                })
                
            successful_posts += 1
            
        if comments_list:
            
            raw_comments_collection = db[raw_comments_collection_name]
            raw_comments_collection.delete_many({})
            raw_comments_collection.insert_many(comments_list)
            print(f"Successfully saved {len(comments_list)} raw comments to MongoDB collection '{raw_comments_collection_name}'")
            
            cleaned_comments_list = [
                {'Bank': c['Bank'], 'Post ID': c['Post ID'], 'Post Caption': c['Post Caption'], 
                'Post Time': c['Post Time'], 'Commenter': c['Commenter'], 'Comment': c['Comment'], 
                'Scraping Time': c['Scraping Time'], 'Classification': c['Classification']}
                for c in comments_list
            ]

            cleaned_comments_collection = db[cleaned_comments_collection_name]
            if cleaned_comments_list:
                cleaned_comments_collection.delete_many({})
                cleaned_comments_collection.insert_many(cleaned_comments_list)
                cleaned_comments_count = len(cleaned_comments_list)
                print(f"Successfully saved {cleaned_comments_count} cleaned comments to MongoDB collection '{cleaned_comments_collection_name}'")
            
            perform_sentiment_analysis()
            update_labels()
            
            labeled_comments_collection = db['labeled_comments']
            labeled_comments_df = pd.DataFrame(list(labeled_comments_collection.find({})))
            total_comments = labeled_comments_df.shape[0]

            percent_positive = "{:.1f}".format((labeled_comments_df[labeled_comments_df['label'] == 'positive'].shape[0] / total_comments) * 100)
            percent_negative = "{:.1f}".format((labeled_comments_df[labeled_comments_df['label'] == 'negative'].shape[0] / total_comments) * 100)
            percent_neutral = "{:.1f}".format((labeled_comments_df[labeled_comments_df['label'] == 'neutral'].shape[0] / total_comments) * 100)  

            comments_df = pd.DataFrame(cleaned_comments_list)
            if not comments_df.empty:
                comments_df['Post Time'] = pd.to_datetime(comments_df['Post Time'])
                comments_df['Year-Month'] = comments_df['Post Time'].dt.strftime('%Y-%m')
                posts_per_month = comments_df.groupby('Year-Month')['Post ID'].nunique().reset_index(name='Posts')
                comments_per_month = comments_df.groupby('Year-Month')['Comment'].count().reset_index(name='Comments')
                combined_df = pd.merge(posts_per_month, comments_per_month, on='Year-Month')
                melted_df = combined_df.melt(id_vars=['Year-Month'], value_vars=['Posts', 'Comments'], var_name='Type', value_name='Counts')
                
                chart_html = generate_plotly_chart(melted_df)
                pie_chart_html = generate_pie_chart(comments_df)
                sentiment_pie_chart_html = generate_sentiment_pie_chart(labeled_comments_df)
                banking_products_bar_chart_html = generate_banking_products_bar_chart(labeled_comments_df)
                timeline_chart_html = generate_sentiment_timeline_chart(labeled_comments_df)

                cleaned_comments_df = pd.DataFrame(list(cleaned_comments_collection.find().limit(10)))
                if not cleaned_comments_df.empty:
                    cleaned_comments_df['_id'] = cleaned_comments_df['_id'].astype(str)
                comments_head_html = cleaned_comments_df.to_html(classes='table table-striped', index=False)

                labeled_comments_df = pd.DataFrame(list(labeled_comments_collection.find().limit(10)))
                if not labeled_comments_df.empty:
                    labeled_comments_df['_id'] = labeled_comments_df['_id'].astype(str)
                labeled_comments_head_html = labeled_comments_df.to_html(classes='table table-striped', index=False)

            else:
                chart_html = "<p>No comments found to generate the chart.</p>"
                pie_chart_html = "<p>No data to generate the pie chart.</p>"
                sentiment_pie_chart_html = "<p>No data to generate the sentiment pie chart.</p>"
                banking_products_bar_chart_html = "<p>No data to generate the banking products bar chart.</p>"
                timeline_chart_html = "<p>No data to generate the sentiment timeline chart.</p>"
                comments_head_html = "<p>No comments found to display in the table.</p>"
                labeled_comments_head_html = "<p>No comments found to display in the table.</p>"
            
            return render_template('home/index.html', bank_name=bank_name, successful_posts=successful_posts, 
                                   cleaned_comments_count=cleaned_comments_count, 
                                   scraping_timestamp=scraping_timestamp, chart_html=chart_html,
                                   pie_chart_html=pie_chart_html,sentiment_pie_chart_html=sentiment_pie_chart_html,
                                   banking_products_bar_chart_html=banking_products_bar_chart_html,
                                   timeline_chart_html=timeline_chart_html,
                                    comments_head_html=comments_head_html, labeled_comments_head_html=labeled_comments_head_html,
                                    percent_positive=percent_positive, percent_negative=percent_negative,percent_neutral=percent_neutral) 
        else:
            return render_template('home/index.html', bank_name=bank_name, successful_posts=successful_posts, 
                                   cleaned_comments_count=cleaned_comments_count, 
                                   scraping_timestamp=scraping_timestamp, chart_html="<p>No comments found to generate the chart.</p>",
                                   pie_chart_html="<p>No data to generate the pie chart.</p>",
                                   sentiment_pie_chart_html="<p>No data to generate the sentiment pie chart.</p>",
                                   banking_products_bar_chart_html="<p>No data to generate the banking products bar chart.</p>",
                                   comments_head_html="<p>No comments found to display in the table.</p>",
                                   labeled_comments_head_html = "<p>No comments found to display in the table.</p>")
    finally:
        driver.quit()
        service.stop()
